# coding:utf-8
from .singleton import singleton
