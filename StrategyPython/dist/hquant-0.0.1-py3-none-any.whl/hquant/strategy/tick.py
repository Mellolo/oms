# coding:utf-8


class Tick:
    pass
