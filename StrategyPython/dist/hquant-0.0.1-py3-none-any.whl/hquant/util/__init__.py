# coding:utf-8
from .serialize import dump_static, load_static
