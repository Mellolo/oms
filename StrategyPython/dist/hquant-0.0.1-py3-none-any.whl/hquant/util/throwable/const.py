# coding:utf-8


class ConstError(TypeError):
    pass


class ConstCaseError(ConstError):
    pass
